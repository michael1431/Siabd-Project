
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link sidebar-link" href="<?php echo e(route('home')); ?>" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Eligibility Check</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link sidebar-link" href="<?php echo e(route('offers')); ?>" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Offers</span>
                            </a>
                        </li>
                       
                        <li class="nav-small-cap"><span class="hide-menu">Components</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-user"></i><span
                                    class="hide-menu">Users Management</span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(route('user.role.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">View Roles
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('user.role.create')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Create Role
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('user.list.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">User List
                                        </span></a>
                                </li>
                            </ul>
                        </li>
                        

                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                            aria-expanded="false"><i class="icon-user"></i><span
                                class="hide-menu"> Student Management</span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(route('student.assign.create')); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Assign Counselor
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('student.new.list',['status'=>'new_leads'])); ?>" class="sidebar-link"><span
                                            class="hide-menu"> New Applied
                                        </span></a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="<?php echo e(route('student.scheduled.list',['status'=>'scheduled'])); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Scheduled
                                        </span>
                                    </a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('student.not_interested.list',['status'=>'not_interested'])); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Not Interested
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('student.not_answered.list',['status'=>'not_answered'])); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Not Answered
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('student.interested.list',['status'=>'interested'])); ?>" class="sidebar-link"><span
                                            class="hide-menu"> Interested
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('student.interested.list',['status'=>'visitor'])); ?>" class="sidebar-link"><span
                                                class="hide-menu"> Visitor
                                        </span></a>
                                </li>
                            </ul>
                        </li>

                        <li class="nav-small-cap"><span class="hide-menu">Administrative</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-user"></i><span
                                    class="hide-menu">Settings</span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(route('setting.country.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Country
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('setting.university.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">University
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('setting.subject.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Subject
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('degree_type_list')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Degree Type
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('setting.program.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Program
                                        </span></a>
                                </li>
                                <li class="sidebar-item"><a href="<?php echo e(route('setting.defaultUploadTitle.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">DefaultUpload Title
                                        </span></a>
                                </li>
                                
                            </ul>
                        </li>
                        <li class="nav-small-cap"><span class="hide-menu">Accounts</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
                                aria-expanded="false"><i class="icon-user"></i><span
                                    class="hide-menu">Accounts Management</span></a>
                            <ul aria-expanded="false" class="collapse  first-level base-level-line">
                                <li class="sidebar-item"><a href="<?php echo e(route('account.head.index')); ?>" class="sidebar-link"><span
                                            class="hide-menu">Accounts Head
                                        </span></a>
                                </li>
                               
                            </ul>
                        </li>
                    </ul> 
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/sections/sidenav.blade.php ENDPATH**/ ?>
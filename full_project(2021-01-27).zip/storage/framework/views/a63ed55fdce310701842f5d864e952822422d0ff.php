
<?php $__env->startSection('title','Student List'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('leads.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleFormControlFile1">Upload Excel File</label>
                            <input type="file" name="file" class="form-control-file" id="exampleFormControlFile1">
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" value="Submit">
                        </div>
                    </form>
                </div>
            </div>


            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Student List</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Counselor</th>
                                    <th>Status</th>
                                    <th>Remarks</th>
                                    <th>Add Remarks & Schedule</th>
                                    <th>Change Status </th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $student_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($student_list->detail->name); ?></td>
                                    <td><?php echo e($student_list->detail->phone); ?></td>
                                    <td><?php echo e(optional(optional($student_list->program)->university)->name); ?>  <?php echo e(optional(optional($student_list->program)->country)->name); ?></td>
                                    <td><?php echo e(optional(optional($student_list->program)->subject)->name); ?></td>
                                    <td><?php echo e($student_list->counselor ? $student_list->counselor->name : 'Yet Not Assign'); ?></td>
                                    <td><?php echo e(strtoupper(str_replace('_',' ',$student_list->status))); ?>

                                    <br>
                                    <?php echo e($student_list->schedule ? $student_list->schedule : 'N/A'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($student_list->remarks? $student_list->remarks : 'N/A'); ?> <br>
                                    </td>
                                     <td>
                                        <button class="btn btn-warning btn-sm m-1 text-white" data-toggle="modal" data-target="#update" type="button" onclick="editForm(<?php echo e($student_list); ?>)">Remarks & Schedule</button>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                        <select name="status" class="custom-select mr-sm-2" id="change_status<?php echo e($student_list->id); ?>" onchange="changeStatus(<?php echo e($student_list->id); ?>)">
                                                <option value="0">Change Status</option>
                                                <option value="new_leads" class="text-warning" <?php if($student_list->status == 'new_leads'): ?> selected <?php endif; ?>>New Applied</option>
                                                <!--<option value="scheduled" class="text-info" <?php if($student_list->status == 'scheduled'): ?> selected <?php endif; ?>>Scheduled</option>-->
                                                <option value="interested" class="text-success" <?php if($student_list->status == 'interested'): ?> selected <?php endif; ?>>Interested</option>
                                                <option value="not_interested" class="text-danger" <?php if($student_list->status == 'not_interested'): ?> selected <?php endif; ?>>Not Interested</option>

                                                <option value="less_interested" class="text-success" <?php if($student_list->status == 'less_interested'): ?> selected <?php endif; ?>>Less Interested</option>
                                                <option value="much_interested" class="text-success" <?php if($student_list->status == 'much_interested'): ?> selected <?php endif; ?> >Much Interested</option>
                                                <option value="done" class="text-success" <?php if($student_list->status ==
                                                 'done'): ?> selected <?php endif; ?> >Done</option>
                                                <option value="not_answered" class="text-dark" <?php if($student_list->status == 'not_answered'): ?> selected <?php endif; ?>>Not Answered</option>
                                            <option value="visitor" class="text-warning" <?php if($student_list->status == 'visitor'): ?> selected <?php endif; ?>>Visitor</option>
                                                
                                            </select>
                                        </div>
                                    </td>
                            
                                    <td>
                                        <a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.show',$student_list->id)); ?>">Details</a>
                                        <a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.edit',$student_list? $student_list->id : '#')); ?>">Edit</a>
                                    </td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="10">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle-2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle-2"> Remarks & Schedule</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <div class="card mb-5">
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data" id="remark">
                            <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="">Remarks</label>
                                        <textarea class="form-control" name="remarks" id="remarks" cols="16" rows="3">
                                    
                                        </textarea>
                                    </div>

                                    <div class="form-group">
                                        <label for="">Schedule</label>
                                        <input name="schedule" type="date" class="form-control">
                                    </div>

                            <button class="btn btn-primary ml-2" type="submit">Save</button>
                        </form>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('script'); ?>

<script>
    function editForm(data){
        var action="<?php echo e(url('')); ?>/add_remarks/"+data.id;
        $('#remark').attr('action',action);
        $('#remarks').attr('value',data.remarks);
    }
</script>

<script>


function changeStatus(student_id){
    var status=$('#change_status'+student_id).val();
    if(status==0){
        alert('Select One of Options');
    }else{
        $.ajax({
            type: "GET",
            url: "<?php echo e(route('default.change_status')); ?>",
            data: { status:status, student_id:student_id }, 
            success: function( msg ) {
                console.log( msg );
                if(msg){
                    location.reload();
                }
            }

            
        });
    }
}
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/student/status_list.blade.php ENDPATH**/ ?>
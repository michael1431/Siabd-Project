
<?php $__env->startSection('title','Counselor Assign'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <form method="post" action="<?php echo e(route('student.assign.store')); ?>">
                <?php echo csrf_field(); ?>
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Counselor Assign</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                       
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <?php if(Auth::user()->role_id==1): ?>
                                    <th>Code</th>
                                    <?php endif; ?>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <?php if(Auth::user()->role_id==1): ?>
                                    <th>Change Status</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $student_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    
                                    <?php if(Auth::user()->role_id==1): ?> 
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="student_id[]" value="<?php echo e($student_list->id); ?>" id="customCheck<?php echo e($key+1); ?>">
                                        <label class="custom-control-label" for="customCheck<?php echo e($key+1); ?>"><?php echo e($student_list->code); ?></label>
                                    </div>
                                    </td>
                                    <?php endif; ?>
                                    <td><?php echo e($student_list->detail->name); ?></td>
                                    <td><?php echo e($student_list->detail->phone); ?></td>
                                    <td><?php echo e($student_list->program->university->name); ?> , <?php echo e($student_list->program->country->name); ?></td>
                                    <td><?php echo e($student_list->program->subject->name); ?></td>
                                    <td><?php echo e(strtoupper(str_replace('_',' ',$student_list->status))); ?></td>
                                    <?php if(Auth::user()->role_id==1): ?>
                                    <td>
                                        <div class="form-group">
                                        <select name="status" class="custom-select mr-sm-2" id="change_status<?php echo e($student_list->id); ?>" onchange="changeStatus(<?php echo e($student_list->id); ?>)">
                                                <option value="0">Change Status</option>
                                                <option value="new_leads" class="text-warning">New Applied</option>
                                                <!--<option value="scheduled" class="text-info">Scheduled</option> -->
                                                <option value="not_interested" class="text-danger">Not Interested</option>
                                                <option value="interested" class="text-success">Interested</option>
                                                <option value="less_interested" class="text-success">Less Interested</option>
                                                <option value="much_interested" class="text-success">Much Interested</option>
                                                <option value="done" class="text-success">Done</option>
                                                <option value="not_answered" class="text-dark">Not Answered</option>
                                            </select>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                    
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="7">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                            <tfoot>
                                <?php if(Auth::user()->role_id==1): ?>
                                <tr>
                                    <th colspan="7">
                                        <div class="form-group">
                                            <label>Select Counselor</label><br>
                                            <select name="counselor" class="custom-select mr-sm-2">
                                                    <?php $__empty_1 = true; $__currentLoopData = $counselors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counselor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                       <option value="<?php echo e($counselor->id); ?>" class="text-dark"><?php echo e($counselor->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                    </th>
                                </tr>
                                <?php endif; ?>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-group text-right">
                        <input type="submit" value="Submit" class="btn btn-danger" style="background-color: #ea1b23">
                    </div>
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/student/assign_list.blade.php ENDPATH**/ ?>
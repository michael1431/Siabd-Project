
<?php $__env->startSection('title','Todays Schedule'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <form method="post" action="<?php echo e(route('student.assign.store')); ?>">
                <?php echo csrf_field(); ?>
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Todays Schedule</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                       
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Remarks</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    
                                    <td><?php echo e($student? $student->detail->name : 'There is no schedule today'); ?></td>
                                    <td><?php echo e($student? $student->detail->phone: ''); ?></td>
                                    <td><?php echo e($student? $student->program->university->name: ''); ?></td>
                                    <td><?php echo e($student?$student->program->subject->name:''); ?></td>
                                    <td><?php echo e($student?strtoupper(str_replace('_',' ',$student->status)):''); ?></td>
                                    <td><?php echo e($student? $student->remarks: ''); ?></td>
                                    <td>
                                        <a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.show',$student? $student->id : '#')); ?>">Details</a>
                                        <a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.edit',$student? $student->id : '#')); ?>">Edit</a>
                                    </td>
                                    
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                                
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                   
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabdupdated\resources\views/student/todays_schedule.blade.php ENDPATH**/ ?>
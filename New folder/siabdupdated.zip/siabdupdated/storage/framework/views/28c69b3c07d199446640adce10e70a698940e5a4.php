<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\siabdupdated\resources\views/sections/preloader.blade.php ENDPATH**/ ?>
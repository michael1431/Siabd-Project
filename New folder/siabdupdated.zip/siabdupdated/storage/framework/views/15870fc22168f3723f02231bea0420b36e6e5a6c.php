<?php $__env->startSection('title','Eligibility Check'); ?>
<?php $__env->startPush('css'); ?>
    <style>
        label,.custom-select{
            font-weight: bold;
            color: black;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="text-primary" style="margin-bottom: 10px;">

      <a href="<?php echo e(url('/home')); ?>" class="btn btn-success">Back</a>
    
    </div>
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title mb-3 mb-5" > <span style="border-bottom: 4px solid grey;padding-bottom:4px;">Eligibility Check</span> </h4>

                    <ul class="nav nav-tabs mb-3" style="display: none">
                        <li class="nav-item">
                            <a href="#home" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                <i class="mdi mdi-home-variant d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 1</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#profile" data-toggle="tab" aria-expanded="false" class="nav-link">
                                <i class="mdi mdi-account-circle d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 2</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link">
                                <i class="mdi mdi-settings-outline d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 3</span>
                            </a>
                        </li>      
                    </ul>
                    <form method="post" action="<?php echo e(route('eligibility_check')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="tab-content">
                            <div class="tab-pane active" id="home">
                               

                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="col-md-2">Select Country </label>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="country" class="custom-select mr-sm-2"
                                                    id="country">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($country->id); ?>"><?php echo e(strtoupper($country->name)); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                    <?php endif; ?>

                                                </select>
                                            </div>
                                        </div>

                                        <label class="col-md-2">Select DegreeType </label>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="degree" class="custom-select mr-sm-2"
                                                        id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($degree->id); ?>"><?php echo e($degree->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">Select University </label>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="university" class="custom-select mr-sm-2"
                                                    id="university">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($university->id); ?>"><?php echo e($university->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <label class="col-md-2">Select Subject </label>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="subject" class="custom-select mr-sm-2"
                                                        id="subject">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions">
                                    
                                    <div class="text-right">
                                        
                                        <a href="#profile" data-toggle="tab" aria-expanded="false" class="nav-link "  >
                                            <i class="mdi mdi-account-circle "  ></i>
                                            <span class="" style="color:white;background-color:red;padding:14px 16px" >Next</span>
                                        </a>
                                    </div>
                                </div>

                            </div>

                           

                            <div class="tab-pane" id="profile">
                                

                                

                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="text-dark col-md-3">Examination</label>
                                        <label class="text-dark col-md-3">Group/Major</label>
                                        <label class="text-dark col-md-3">GPA</label>
                                    </div>
                                    <div class="form-group row">
                                        <label class="text-dark col-md-3">SSC</label>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select name="ssc_group" class="custom-select mr-sm-2"
                                                    id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <option value="1">Science</option>
                                                    <option value="2">Business Studies</option>
                                                    <option value="3">Humanities</option>
                                                    <option value="4">General</option>
                                                    <option value="5">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="5" step=".01">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="text-dark col-md-3">HSC</label>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select name="hsc_group" class="custom-select mr-sm-2"
                                                    id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <option value="1">Science</option>
                                                    <option value="2">Business Studies</option>
                                                    <option value="3">Humanities</option>
                                                    <option value="4">General</option>
                                                    <option value="5">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="5" step=".01">
                                        </div>
                                        


                                    </div>
                                    <div class="form-group row">
                                        <label class="text-dark col-md-3">Hon's</label>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select name="hsc_group" class="custom-select mr-sm-2"
                                                    id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <option value="1">Science</option>
                                                    <option value="2">Business Studies</option>
                                                    <option value="3">Humanities</option>
                                                    <option value="4">General</option>
                                                    <option value="5">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="5" step=".01">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="text-dark col-md-3">Masters</label>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select name="hsc_group" class="custom-select mr-sm-2"
                                                    id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <option value="1">Science</option>
                                                    <option value="2">Business Studies</option>
                                                    <option value="3">Humanities</option>
                                                    <option value="4">General</option>
                                                    <option value="5">Other</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="5" step=".01">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-actions">
                                    <div class="text-right">
                                        

                                        <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link">
                                            <i class="mdi mdi-account-circle "  ></i>
                                            <span class="" style="color:white;background-color:red;padding:14px 16px" >Next</span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane" id="settings">
                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="col-md-2">IELTS </label>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation2" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation2">yes </label>
                                                    </div>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation3" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation3">no </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="9" step=".01">
                                        </div>


                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">TOFEL </label>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation11" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation2">yes </label>
                                                    </div>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation12" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation3">no </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="9" step=".01">
                                        </div>


                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">GRE </label>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation1" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation1">yes </label>
                                                    </div>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation4" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation4">no </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="9" step=".01">
                                        </div>


                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">GMAT </label>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation5" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation5">yes </label>
                                                    </div>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" class="custom-control-input"
                                                            id="customControlValidation6" name="radio-stacked">
                                                        <label class="custom-control-label"
                                                            for="customControlValidation6">no </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" class="form-control" max="9" step=".01">
                                        </div>


                                    </div>

                                    <div class="form-actions">
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-info">Submit</button>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabdupdated\resources\views/home.blade.php ENDPATH**/ ?>
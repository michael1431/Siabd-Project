<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/sections/preloader.blade.php ENDPATH**/ ?>
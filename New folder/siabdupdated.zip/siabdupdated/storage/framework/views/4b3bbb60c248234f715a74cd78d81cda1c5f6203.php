
<?php $__env->startSection('title','Counselor Assign'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('leads.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">Upload Excel File</label>
                                <input type="file" name="file" class="form-control-file" id="exampleFormControlFile1">
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="multi_col_order"
                                   class="table table-striped table-bordered display no-wrap" style="width:100%">
                                <thead>
                                <tr>

                                    <th>S/L</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Remark</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($lead->name); ?></td>
                                        <td><?php echo e($lead->phone); ?></td>
                                        <td><?php echo e($lead->email); ?></td>
                                        <td><?php echo e($lead->remarks); ?></td>
                                        <td>
                                            <a href="#" style="background-color: #ea1b23"  data-toggle="modal" data-target="#edit<?php echo e($lead->id); ?>" class="btn btn-danger">Edit</a>
                                            <a href="<?php echo e(route('leads.delete',$lead->id)); ?>" style="background-color: #ea1b23" class="btn btn-danger">x</a>
                                        </td>
                                    </tr>

                                    <!-- Modal -->
            <div class="modal fade" id="edit<?php echo e($lead->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <form action="<?php echo e(route('leads.update',$lead->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel">Edit Leads</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="exampleFormControlFile1">Name</label>
                                                            <input type="text" name="name" class="form-control" value="<?php echo e($lead->name); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleFormControlFile1">Email</label>
                                                            <input type="text" name="email" class="form-control" value="<?php echo e($lead->email); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleFormControlFile1">Phone</label>
                                                            <input type="text" name="phone" class="form-control" value="<?php echo e($lead->phone); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="remarks">Remarks</label>
                                                            <input type="text" name="remarks" class="form-control" id="remarks" value="<?php echo e($lead->remarks); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Update</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>No Leads</p>
                                <?php endif; ?>
                                </tbody>
                                <tfoot>

                                </tfoot>
                            </table>
                        </div>

                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row-->
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/Leads/index.blade.php ENDPATH**/ ?>
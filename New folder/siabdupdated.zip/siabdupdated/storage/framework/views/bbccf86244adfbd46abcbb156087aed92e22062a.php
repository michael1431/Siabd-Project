
<?php $__env->startSection('title',strtoupper(auth()->user()->role->name)." ".'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
<body>

	

	<div class="container mt-2">
		<div class="navigation-outer">

		
         <ul class="navigation-top list-unstyled align-items-center mb-0">
          
            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'new_leads'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">NEW LEADS</p>
            </li>
           
            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'interested'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10"> INTERESTED</p>
            </li><li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'much_interested'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">MUCH INTERESTED</p>
            </li>
            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'less_interested'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">LESS INTERESTED</p>
            </li>
            
         </ul>
			
			
         <ul class="navigation-top list-unstyled align-items-center mb-0">
           
            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'not_interested'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">NOT INTERESTED</p>
            </li>

            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'not_answered'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">NOT ANSWERED</p>
            </li> 
            <li class="navigation-link">
               <a href="<?php echo e(route('visitor.list')); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">VISITORS</p>
            </li>
            <li class="navigation-link">
               <a href="<?php echo e(route('student.new.list',['status'=>'done'])); ?>">
                  <img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
               </a>
               <p class="--fs-10">DONE</p>
            </li>
				
			</ul>
		</div>
	</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/student/report_menu.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title',strtoupper(auth()->user()->role->name)." ".'DASHBOARD'); ?>
<?php $__env->startSection('content'); ?>
<body>

	

	<div class="container mt-2">
		<div class="navigation-outer">

			

			
			<?php if(Auth::user()->role_id==1): ?>
			
				<ul class="navigation-top list-unstyled align-items-center mb-0">
					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.schedule')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">TODAY'S SCHEDULE</p>
					</li>

					<li class="navigation-link">
						<a href="<?php echo e(route('check')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">ELIGIBILITY CHECK</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.create')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">APPLICATION</p>
					</li>
					

					
						
						
						
					<li class="navigation-link">
						<a href="<?php echo e(route('user.list.index',['role'=>4])); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/partner.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">PARTNERS</p>
					</li>

					<li class="navigation-link">
						<a href="<?php echo e(route('track.list')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/partner.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">TRACK ACTIVITY</p>
					</li>
											
						
				</ul>

				
				
				<ul class="navigation-bottom list-unstyled align-items-center mb-0">

					<?php if(Auth::user()->role_id==2): ?>
						<li class="navigation-link">
							<a href="<?php echo e(route('offers')); ?>">
								<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
							</a>
							<p class="--fs-24 --fw-b">OVERVIEW</p>
						</li>

						<li class="navigation-link">
							<a href="<?php echo e(route('studentlist.update_remarks')); ?>">
								<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
							</a>
							<p class="--fs-24 --fw-b">UPDATE & REMARKS</p>
						</li>
					<?php endif; ?>
					<li class="navigation-link">
							
						<div class="dropdown">
							<a onclick="myFunction()" class="dropbtn">
								<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/account.png" alt="">
							</a>
						</div>
						<p class="--fs-24 --fw-b">ACCOUNT</p>
					</li>

						
					<li class="navigation-link">
						<a href="<?php echo e(route('student.assign.create')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/activity.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">ACTIVITY</p>
					</li>
					<li class="navigation-link">
						<a href="<?php echo e(route('offers')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">OVERVIEW</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('student.report.menu')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/sale.png" alt="">
						</a>
						
						<p class="--fs-24 --fw-b">REPORT</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('user.list.index',['role'=>3])); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/counselor.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">COUNSELOR</p>
					</li>
					<li class="navigation-link">                
						<a href="<?php echo e(route('user.role.index')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/cpanel.png" alt="">
						</a>
						<p class="--fs-24 --fw-b"> <?php echo e('SETTINGS'); ?></p>
					</li>
					
				</ul>
				
			<?php endif; ?>

			<?php if(Auth::user()->role_id==2): ?>
			<ul class="navigation-top list-unstyled align-items-center mb-0">
				
				<li class="navigation-link">
					<a href="<?php echo e(route('check')); ?>">
						<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
					</a>
					<p class="--fs-24 --fw-b">ELIGIBILITY CHECK</p>
				</li>
				
				<li class="navigation-link">
					<a href="<?php echo e(route('studentlist.create')); ?>">
						<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
					</a>
					<p class="--fs-24 --fw-b">APPLICATION</p>
				</li>
				
				
			</ul>

			
			
			<ul class="navigation-bottom list-unstyled align-items-center mb-0">

					<li class="navigation-link">
						<a href="<?php echo e(route('offers')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">OVERVIEW</p>
					</li>

					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.update_remarks')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">UPDATE & REMARKS</p>
					</li>
				
			</ul>
			<?php endif; ?>

			
			<?php if(Auth::user()->role_id==3): ?>
				<ul class="navigation-top list-unstyled align-items-center mb-0">
					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.schedule')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">TODAY'S SCHEDULE</p>
					</li>
					<li class="navigation-link">
						<a href="<?php echo e(route('check')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">ELIGIBILITY CHECK</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.create')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">APPLICATION</p>
					</li>
					
					
											
						<li class="navigation-link">
							
							<div class="dropdown">
								<a onclick="myFunction()" class="dropbtn">
									<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/account.png" alt="">
								</a>
							</div>
							<p class="--fs-24 --fw-b">ACCOUNT</p>
						</li>
				</ul>

			
			
				<ul class="navigation-bottom list-unstyled align-items-center mb-0">

			
						
					<li class="navigation-link">
						<a href="<?php echo e(route('student.assign.create')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/activity.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">ACTIVITY</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('offers')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">OVERVIEW</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('student.report.menu')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/sale.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">REPORT</p>
					</li>
					
					
					
				</ul>
			<?php endif; ?>

			
			
			<?php if(Auth::user()->role_id==4): ?>
				<ul class="navigation-top list-unstyled align-items-center mb-0">
					
					<li class="navigation-link">
						<a href="<?php echo e(route('check')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/eligibilitycheck.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">ELIGIBILITY CHECK</p>
					</li>
					
					<li class="navigation-link">
						<a href="<?php echo e(route('studentlist.create')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/applications.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">APPLICATION</p>
					</li>
					
					
						
				</ul>

			
			
				<ul class="navigation-bottom list-unstyled align-items-center mb-0">

								
					<li class="navigation-link">
							
						<div class="dropdown">
							<a onclick="myFunction()" class="dropbtn">
								<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/account.png" alt="">
							</a>
						</div>
						<p class="--fs-24 --fw-b">ACCOUNT</p>
					</li>
						
					
					<li class="navigation-link">
						<a href="<?php echo e(route('offers')); ?>">
							<img class="img-fluid" src="<?php echo e(asset('new_template')); ?>/img/overview.png" alt="">
						</a>
						<p class="--fs-24 --fw-b">OVERVIEW</p>
					</li>
					
					
					
					
					
				</ul>
			<?php endif; ?>
			
		</div>
	</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/dashboard/index2.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('template')); ?>/assets/images/favicon_sia.png">

	<!-- Bootstrap CSS -->
	<link href="<?php echo e(asset('template')); ?>/assets/extra-libs/c3/c3.min.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('new_template')); ?>/css/bootstrap.min.css">

	<!-- Animate CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('new_template')); ?>/css/animate.css">

	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('new_template')); ?>/css/owl.carousel.min.css">
	<link href="<?php echo e(asset('template')); ?>/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
	<link href="<?php echo e(asset('template')); ?>/dist/css/style.min.css" rel="stylesheet">

	<!-- Fontawesome Kit -->
	<script src="<?php echo e(asset('new_template')); ?>/js/fontawesome.js"></script>

	<!-- Style -->
	<link rel="stylesheet" href="<?php echo e(asset('new_template')); ?>/css/style.css">

	<title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
    <div class="">
        <a href="<?php echo e(route('logout')); ?>" style=" " onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn btn-sm  text-white --sia-red-bg">LOGOUT</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
    
	<header class="d-flex justify-content-center animated slideInDown">
        <a href="<?php echo e(route('dashboard')); ?>">
        <img src="<?php echo e(asset('new_template')); ?>/img/logo.jpg" alt="">
        </a> 
    </header>
    
    


	<div class="container mt-2">
        <?php if(Session::has('message')): ?>
        <div style="margin: auto;max-width: 70%;" class="alert alert-<?php echo e(Session::get('type')); ?> alert-dismissible bg-<?php echo e(Session::get('type')); ?> text-white border-0 fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <strong><?php echo e(strtoupper(Session::get('type'))); ?> - </strong> <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
		<div class="d-flex justify-content-center">
			<div class="dashboard-heading text-center --fs-40 --fw-b">
				<?php echo $__env->yieldContent('title'); ?>
				                 
			</div>
		</div>
	</div>
<?php echo $__env->yieldContent('content'); ?>

<footer class="container-fluid footer_style" style="position:fixed !important;bottom 0 !important">
    <div class="d-flex justify-content-between align-items-center">
        <div class="footer-info">
            <div class="--fs-20 --fw-b">YOUR ONE STOP SOLUTION FOR</div>
            <ul class="p-0 d-flex">
                <li class="--fs-20 --fw-b">STUDENT VISA</li>
                <li class="--fs-20 --fw-b ml-4">SCHOOLING VISA</li>
                <li class="--fs-20 --fw-b ml-4">SKILL MIGRATION</li>
            </ul>
        </div>
        
        
    </div>
</footer>

<script src="<?php echo e(asset('new_template')); ?>/js/custom.js"></script>
<script src="<?php echo e(asset('template')); ?>/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('template')); ?>/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="<?php echo e(asset('template')); ?>/dist/js/app-style-switcher.js"></script>
    <script src="<?php echo e(asset('template')); ?>/dist/js/feather.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('template')); ?>/dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <script src="<?php echo e(asset('template')); ?>/assets/extra-libs/c3/d3.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/extra-libs/c3/c3.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo e(asset('template')); ?>/assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo e(asset('template')); ?>/dist/js/pages/dashboards/dashboard1.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    <script>
        $(document).ready(function(){
            $('#country').on('change', function(){
                var countryID = $(this).val();
                if(countryID){
                    $.ajax({
                        type:'GET',
                        url:"<?php echo e(route('default.get_university')); ?>",
                        data:'country_id='+countryID,
                        success:function(html){
                            $('#university').html(html);
                            // $('#city').html('<option value="">Select university first</option>'); 
                        }
                    }); 
                }else{
                    $('#university').html('<option value="">Select Country first</option>');
                    // $('#city').html('<option value="">Select Counrty first</option>'); 
                }
            });
            
            $('#university').on('change', function(){
                var university = $(this).val();
                if(university){
                    $.ajax({
                        type:'GET',
                        url:"<?php echo e(route('default.get_subject')); ?>",
                        data:'university_id='+university,
                        success:function(html){
                            $('#subject').html(html);
                        }
                    }); 
                }else{
                    $('#subject').html('<option value="">Select Counrty first</option>'); 
                }
            });
            $('#subject').on('change', function(){
                var subject = $(this).val();
                var university = $('#university').val();
                if(university){
                    $.ajax({
                        type:'GET',
                        url:"<?php echo e(route('default.get_program')); ?>",
                        data:{ university_id: university, subject_id: subject },
                        success:function(html){
                            $('#degree').html(html);
                        }
                    }); 
                }else{
                    $('#degree').html('<option value="">Select Counrty first</option>'); 
                }
            });
        });
        window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove(); 
            });
        }, 2000);
    </script>

</body>
</html><?php /**PATH E:\Rezaul Hoque\siabdUpdate\siabdupdate\resources\views/layouts/new_master.blade.php ENDPATH**/ ?>
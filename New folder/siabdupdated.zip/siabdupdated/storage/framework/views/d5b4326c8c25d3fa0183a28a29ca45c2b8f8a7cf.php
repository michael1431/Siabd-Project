
<?php $__env->startSection('title','Eligibility Result'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="background-image: url('new_template/img/arch.jpg')">

   <div class="text-primary" style="margin-bottom: 10px;">

      <a href="<?php echo e(url('/check')); ?>" class="btn btn-success">Back</a>
    
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Eligibility Result</h4>
                   
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Code</th>
                                    <th>Degree</th>
                                    <th>University</th>
                                    <th>Country</th>
                                    <th>Tuition Fee</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($programme->code); ?></td>
                                    <td><?php echo e($programme->degree); ?></td>
                                    <td><?php echo e($programme->university->name); ?></td>
                                    <td><?php echo e($programme->country->name); ?></td>
                                    <td><?php echo e($programme->tuition_fee); ?></td>
                                    <td><a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.create',['program_id'=>$programme->id])); ?>">Apply</a></td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabdupdated\resources\views/eligibility_test_result.blade.php ENDPATH**/ ?>
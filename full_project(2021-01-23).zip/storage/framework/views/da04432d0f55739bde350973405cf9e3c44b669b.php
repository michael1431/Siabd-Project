
<?php $__env->startSection('title','Visitor List'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="">
                    <h4 class="">Search by Status</h4>
                    <div class="form-group">
                        <select name="search_visit_status" id="search_status" class="custom-select mr-sm-2" id="">
                            <option value="0">Select Status</option>
                            <option value="new_leads" class="text-warning" >New Applied</option>
                            <option value="scheduled" class="text-info" >Scheduled</option>
                            <option value="interested" class="text-success" >Interested</option>
                            <option value="not_interested" class="text-danger" >Not Interested</option>

                            <option value="less_interested" class="text-success" >Less Interested</option>
                            <option value="much_interested" class="text-success"  >Much Interested</option>
                            <option value="done" class="text-success" >Done</option>
                            <option value="not_answered" class="text-dark">Not Answered</option>
                            <option value="visitor" class="text-dark">Visitor</option>
                        </select>
                    </div>
                    <form action="" method="get" id="search">
                        
                    <div class="form-group">
                        <button class="btn btn-sm text-white" style="background-color: #ea1b23" type="submit" onclick="search_visit_status()">Search</button>
                    </div>
                    </form>
                </div>
                
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Visitor List</h4>
                    
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Guardian</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Change Status</th>
                                    <th> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($visitor->name); ?></td>
                                    <td><?php echo e($visitor->phone); ?></td>
                                    <td><?php echo e($visitor->guardian); ?></td>
                                    <td><?php echo e(($visitor->university?$visitor->university->name:'')); ?>-<?php echo e(($visitor->country?$visitor->country->name:'')); ?></td>
                                    <td><?php echo e($visitor->subject); ?></td>
                                    <td><?php echo e(strtoupper(str_replace('_',' ',$visitor->status))); ?></td>
                                    <td>
                                        <div class="form-group">
                                        <select name="status" class="custom-select mr-sm-2" id="change_status<?php echo e($visitor->id); ?>" onchange="status(<?php echo e($visitor->id); ?>)">
                                                <option value="0">Change Status</option>
                                                <option value="new_leads" class="text-warning" <?php if($visitor->status == 'new_leads'): ?> selected <?php endif; ?>>New Applied</option>
                                                <option value="scheduled" class="text-info" <?php if($visitor->status == 'scheduled'): ?> selected <?php endif; ?>>Scheduled</option>
                                                <option value="interested" class="text-success" <?php if($visitor->status == 'interested'): ?> selected <?php endif; ?>>Interested</option>
                                                <option value="not_interested" class="text-danger" <?php if($visitor->status == 'not_interested'): ?> selected <?php endif; ?>>Not Interested</option>

                                                <option value="less_interested" class="text-success" <?php if($visitor->status == 'less_interested'): ?> selected <?php endif; ?>>Less Interested</option>
                                                <option value="much_interested" class="text-success" <?php if($visitor->status == 'much_interested'): ?> selected <?php endif; ?> >Much Interested</option>
                                                <option value="done" class="text-success" <?php if($visitor->status ==
                                                 'done'): ?> selected <?php endif; ?> >Done</option>
                                                <option value="not_answered" class="text-dark" <?php if($visitor->status == 'not_answered'): ?> selected <?php endif; ?>>Not Answered</option>
                                                <option value="visitor" class="text-warning" <?php if($visitor->status == 'visitor'): ?> selected <?php endif; ?>>visitor</option>

                                            </select>
                                        </div>
                                    </td>
                                    <td>
                                        <a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('visitor.show',$visitor->id)); ?>">Details</a></td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="9">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>


function status(visitor_id){
    var status=$('#change_status'+visitor_id).val();
    
    if(status==0){
        alert('Select One of Options');
    }else{
        $.ajax({
            type: "GET",
            url: "<?php echo e(route('visitor_status')); ?>",
            data: { status:status, visitor_id:visitor_id }, 
            
            success: function( msg ) {
                console.log( msg );
                if(msg){
                    location.reload();
                }
            }
            
        });
    }
}

</script>

<script>
    function search_visit_status(){
        var status = $('#search_status option:selected').val();
        
        var action="<?php echo e(url('')); ?>/visitor/search/status/"+status;
        $('#search').attr('action',action);
        // $('#remarks').attr('value',data.remarks);
};
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/student/visitor_list.blade.php ENDPATH**/ ?>
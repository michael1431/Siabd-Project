
<?php $__env->startSection('title','Program Offers'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container mt-2">
		<div class="navigation-outer">
            <?php if(!$programmes): ?>
                <ul class="navigation-top list-unstyled align-items-center mb-0">
                    <?php
                        $index=0;
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $index++;
                    ?>
                    <li class="navigation-link">
                        <a href="<?php echo e(route('offers',['country'=>$country->id])); ?>">
                            <img class="img-fluid" src="<?php echo e(asset($country->flag_image)); ?>" onerror="this.onerror=null; this.src=<?php echo e(asset($country->flag_image)); ?>" alt="img">
                        </a>
                        
                    </li>
                    <?php if($index%4==0): ?>
                </ul>
                    <ul class="navigation-top list-unstyled align-items-center mb-0">
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
                <ul class="navigation-top list-unstyled align-items-center mb-0">
                    <?php
                        $uindex=0;
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $uindex++;
                    ?>
                    <li class="navigation-link">
                        <a href="<?php echo e(route('offers',['university'=>$university->id])); ?>">
                            <img class="img-fluid" src="<?php echo e(asset($university->logo_image)); ?>" alt="">
                        </a>
                        <p class="--fs-10 --fw-b"><?php echo e($university->name); ?></p>
                    </li>
                    <?php if($uindex%4==0): ?>
                </ul>
                <ul class="navigation-top list-unstyled align-items-center mb-0">
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
       <?php else: ?>
        <div class="row">
            <div class="col-12">
                <div class="card" style="border:1px solid #ea1b23">
                    <div class="card-header" style="background-color: #ea1b23">
                        <h4 class="text-white">Programe List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="multi_col_order" class="table table-striped table-bordered display no-wrap"
                                style="width:100%">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Code</th>
                                        <th>Degree</th>
                                        <th>Subject</th>
                                        <th>University</th>
                                        <th>Country</th>
                                        <th>Tuition Fee</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($programme->code); ?></td>
                                        <td><?php echo e($programme->degree); ?></td>
                                        <td><?php echo e($programme->subject->name); ?></td>
                                        <td><?php echo e($programme->university->name); ?></td>
                                        <td><?php echo e($programme->country->name); ?></td>
                                        <td><?php echo e($programme->tuition_fee); ?></td>
                                        <td>
                                            <a class="btn btn-danger" style="background-color: #ea1b23"
                                                href="<?php echo e(route('studentlist.create',['program_id'=>$programme->id])); ?>">Apply</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>


                                </tbody>
                            </table>
                            <?php echo e($programmes->appends(request()->except('page'))->render()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
   
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/program/offers.blade.php ENDPATH**/ ?>
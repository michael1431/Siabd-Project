
<?php $__env->startSection('title','Student Details'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Student Details</h4>
                </div>
                <div class="card-body">


                    
                        
                        <div class="form-body">
                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0 !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Personal Information</legend>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Full Name</label>
                                <div class="col-md-8">
                                    <div class="form-group">
                                    <input type="text" class="form-control" name="name" id="" value="<?php echo e($student->detail->name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Phone</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" id="" value="<?php echo e($student->detail->phone); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Email</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" id="" value="<?php echo e($student->detail->email); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Father's Name</label>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="f_name" id="" value="<?php echo e($student->f_name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Father's Profession</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="f_profession" id="" value="<?php echo e($student->f_profession); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Father's Contact</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="f_contact" id="" value="<?php echo e($student->f_contact); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Mother's Name</label>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="m_name" id="" value="<?php echo e($student->m_name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Passport No</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="passport_no" id="" value="<?php echo e($student->passport_no); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">NID No</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="nid" id="" value="<?php echo e($student->nid); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">BIR No</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="b_reg_no" id="" value="<?php echo e($student->b_reg_no); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Home Phone</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone_home" id="" value="<?php echo e($student->phone_home); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <div class="col-md-5">
                                    <label class="text-dark">Present Address</label>
                                    <div class="form-group">
                                       <textarea name="present_address" id="" class="form-control" rows="10"><?php echo e($student->present_address); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <label class="text-dark">Parmenent Address</label>
                                    <div class="form-group">
                                        <textarea name="permanent_address" id="" class="form-control" rows="10"><?php echo e($student->permanent_address); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            </fieldset>

                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0 !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Educational Competence</legend>
                                  
                    <div class="table-responsive">
                       
                        <table id="multi_col_order" class="table table-striped table-bordered display no-wrap"
                        style="width:100%">
                        <thead>
                            <tr>
                                <th>Examination</th>
                                
                                <th>Subject/Major</th>
                                <th>GPA</th>
                                <th>YEAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $ssc=json_decode($student->ssc);
                                $hsc=json_decode($student->hsc);
                                $hons=json_decode($student->hons);
                                $masters=json_decode($student->masters);
                                $others=json_decode($student->others);
                            ?>
                            <?php if($ssc): ?>
                           
                           <tr>
                                <th>SSC</th>
                                
                                <td><?php echo e($ssc->group); ?></td>
                                <td><?php echo e($ssc->gpa); ?></td>
                                <td><?php echo e($ssc->year); ?></td>
                                

                           </tr>
                           <?php endif; ?>
                           <?php if($hsc): ?>
                           <tr>
                                <th>HSC</th>
                                
                                <td><?php echo e($hsc->group); ?></td>
                                <td><?php echo e($hsc->gpa); ?></td>
                                <td><?php echo e($hsc->year); ?></td>
                                

                           </tr>
                           <?php endif; ?>
                           <?php if($hons): ?>
                           <tr>
                                <th>HONS.</th>
                                
                                <td><?php echo e($hons->group); ?></td>
                                <td><?php echo e($hons->gpa); ?></td>
                                <td><?php echo e($hons->year); ?></td>
                                

                           </tr>
                           <?php endif; ?>
                           <?php if($masters): ?>
                           <tr>
                                <th>MASTERS</th>
                                
                                <td><?php echo e($masters->group); ?></td>
                                <td><?php echo e($masters->gpa); ?></td>
                                <td><?php echo e($masters->year); ?></td>
                                

                           </tr>
                           <?php endif; ?>
                           <?php if($others): ?>
                           <tr>
                                <th><?php echo e($others->title); ?></th>
                                
                                <td><?php echo e($others->group); ?></td>
                                <td><?php echo e($others->gpa); ?></td>
                                <td><?php echo e($others->year); ?></td>
                                

                           </tr>
                           <?php endif; ?>
                           <?php if($student->additional_skill): ?>
                           <tr>
                                <th><?php echo e($student->additional_skill); ?></th>
                                <td>-</td>
                                <td>-</td>
                                <td><?php echo e($student->additional_skill_score); ?></td>
                                <td>-</td>
                                

                           </tr>
                           <?php endif; ?>


                        </tbody>
                        
                    </table>
                        </div>
                            </fieldset>
                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0   !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Documents</legend>
                                <div class="table-responsive">
                       
                                    <table id="multi_col_order" class="table table-striped table-bordered display no-wrap"
                                        style="width:100%">
                                        <thead>
                                            <tr>
                                                 <?php $__empty_1 = true; $__currentLoopData = $student->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <th>
                                                    
                                                    <a class="btn btn-link" href="<?php echo e(asset($item->file_location)); ?>"><?php echo e(strtoupper(str_replace('_',' ',$item->document_title))); ?></a>
                                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                                <th >
                                    
                                    <form method="post" action="<?php echo e(route('documents.store')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="document_title" placeholder="document_title" id="">
                                                </div>
                                                <input type="hidden" value="<?php echo e($student->id); ?>" name="student_id" required>   
                                </th>
                                <th>
                                            <div class="form-group">
                                                <button class="btn btn-danger">Add Title</button>
                                            </div>
                                        </div>
                                    </form>
                                </th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                               
                            </fieldset>

                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0   !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Remarks</legend>
                                <div class="table-responsive">
                                    <p><?php echo e($student->remarks); ?></p>
                                </div>
                               
                            </fieldset>
                            
                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0   !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                              <legend style="width:inherit;padding:0 10px;border-bottom:none;">Schedule</legend>
                              <div class="table-responsive">
                                  <p><?php echo e($student->schedule); ?></p>
                              </div>
                             
                            </fieldset>
                                                                  
                       

                        </div>
                        <div class="form-actions">
                            <div class="text-right">
                                <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Verify</button>
                            </div>
                        </div>
                    </form>




                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/track/view.blade.php ENDPATH**/ ?>
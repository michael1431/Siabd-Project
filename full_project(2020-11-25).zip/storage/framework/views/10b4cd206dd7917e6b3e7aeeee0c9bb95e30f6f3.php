<footer class="footer text-center">
    All Rights Reserved by Ringersoft LTD. Designed and Developed by <a
        href="https://mr.theprofoundit.com">M R RAHMAN</a>.
</footer><?php /**PATH C:\xampp\htdocs\siabd\resources\views/sections/footer.blade.php ENDPATH**/ ?>
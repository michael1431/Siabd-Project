<div class="page-breadcrumb">
    <div class="row">
        <div class="col-7 align-self-center">
            <h3 class="page-title text-truncate text-dark font-weight-medium mb-1"><span style="color:#ea1b23">Good Morning</span> <?php echo e(Auth::user()->name); ?>!</h3>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb m-0 p-0">
                        <li style="color:#ea1b23" class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a> =>> <?php echo $__env->yieldContent('title'); ?>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="col-5 align-self-center">
            <div class="customize-input float-right">
                <select class="custom-select custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                    <option selected><?php echo e(date('d F,Y')); ?></option>
                </select>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/sections/breadcrumb.blade.php ENDPATH**/ ?>
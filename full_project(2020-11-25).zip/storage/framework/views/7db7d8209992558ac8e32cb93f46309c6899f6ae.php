
<?php $__env->startSection('title','All Roles'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">User Role List <a href="<?php echo e(route('user.role.create')); ?>" class="btn btn-dark float-right">Add New</a></h4>
                   
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="multi_col_order" class="table table-striped table-bordered display"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <td> #SL</td>
                                    <td>Roles</td>
                                    <td> Permissions</td>
                                    <td> Action</td>
                                </tr>
                            </thead>

                            <tbody>
                                
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e($key+1); ?></td>
                                    <td> <?php echo e(strtoupper($info->name)); ?></td>
                                    <td>
                                        <?php $__empty_2 = true; $__currentLoopData = $info->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="badge badge-info"><?php echo e($permission->lebel); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('user.role.edit',$info->id)); ?>"
                                            class="btn btn-edit btn-success far fa-edit"></a>
                                        

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>




                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/users/view-role.blade.php ENDPATH**/ ?>
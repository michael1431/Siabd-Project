
<?php $__env->startSection('title','Counselor Assign'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <form method="post" action="<?php echo e(route('student.assign.store')); ?>">
                <?php echo csrf_field(); ?>
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Counselor Assign</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                       
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $student_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="student_id[]" value="<?php echo e($student_list->id); ?>" id="customCheck<?php echo e($key+1); ?>">
                                        <label class="custom-control-label" for="customCheck<?php echo e($key+1); ?>"><?php echo e($student_list->code); ?></label>
                                    </div></td>
                                    <td><?php echo e($student_list->detail->name); ?></td>
                                    <td><?php echo e($student_list->detail->phone); ?></td>
                                    <td><?php echo e($student_list->program->university); ?> , <?php echo e($student_list->program->country); ?></td>
                                    <td><?php echo e($student_list->program->subject); ?></td>
                                    <td><?php echo e(strtoupper(str_replace('_',' ',$student_list->status))); ?></td>
                                   
                                    
                                    
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="6">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6">
                                        <div class="form-group">
                                            <label>Select Counselor</label><br>
                                            <select name="counselor" class="custom-select mr-sm-2">
                                                    <?php $__empty_1 = true; $__currentLoopData = $counselors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counselor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                       <option value="<?php echo e($counselor->id); ?>" class="text-dark"><?php echo e($counselor->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-group text-right">
                        <input type="submit" value="Submit" class="btn btn-danger" style="background-color: #ea1b23">
                    </div>
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
// function changeStatus(student_id){
//     var status=$('#change_status'+student_id).val();
//     if(status==0){
//         alert('Select One of Options');
//     }else{
//         $.ajax({
//             type: "GET",
//             url: "<?php echo e(route('default.change_status')); ?>",
//             data: { status:status, student_id:student_id }, 
//             success: function( msg ) {
//                 console.log( msg );
//                 if(msg){
//                     location.reload();
//                 }
//             }
//         });
//     }
// }
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/student/assign_list.blade.php ENDPATH**/ ?>
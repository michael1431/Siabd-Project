
<?php $__env->startSection('title','Visitor Details'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Visitor Details</h4>
                </div>
                <div class="card-body">


                    
                        
                        <div class="form-body">
                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0 !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Personal Information</legend>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Full Name</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                    <input type="text" class="form-control" name="name" id="" value="<?php echo e($visitor->name); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Guardian Name</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="guardian" id="" value="<?php echo e($visitor->guardian); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Phone</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" id="" value="<?php echo e($visitor->phone); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Email</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" id="" value="<?php echo e($visitor->email); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Country</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" value="<?php echo e($visitor->country->name); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">University</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="" value="<?php echo e($visitor->university->name); ?>" readonly>
                                    </div>
                                </div>
                               
                                <div class="col-md-1"></div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Subject</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" value="<?php echo e($visitor->subject); ?>" readonly>
                                    </div>
                                </div>
                                <label class="col-md-2 text-dark">Degree Type</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="" value="<?php echo e($visitor->degreeType->name); ?>" readonly>
                                    </div>
                                </div>
                               
                                <div class="col-md-1"></div>
                            </div>
                            </fieldset>

                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0 !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Educational Competence</legend>
                                
                                    
                    <div class="table-responsive">
                       
                        <table id="multi_col_order" class="table table-striped table-bordered display no-wrap"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>Examination</th>
                                    <th>Institution</th>
                                    <th>Subject/Major</th>
                                    <th>GPA</th>
                                    <th>YEAR</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $ssc=json_decode($visitor->ssc);
                                    $hsc=json_decode($visitor->hsc);
                                    $hons=json_decode($visitor->hons);
                                    $masters=json_decode($visitor->masters);
                                    $others=json_decode($visitor->others);
                                ?>
                                <?php if($ssc): ?>
                               
                               <tr>
                                    <th>SSC</th>
                                    <td><?php echo e($ssc->institution); ?></td>
                                    <td><?php echo e($ssc->group); ?></td>
                                    <td><?php echo e($ssc->gpa); ?></td>
                                    <td><?php echo e($ssc->year); ?></td>
                                    

                               </tr>
                               <?php endif; ?>
                               <?php if($hsc): ?>
                               <tr>
                                    <th>HSC</th>
                                    <td><?php echo e($hsc->institution); ?></td>
                                    <td><?php echo e($hsc->group); ?></td>
                                    <td><?php echo e($hsc->gpa); ?></td>
                                    <td><?php echo e($hsc->year); ?></td>
                                    

                               </tr>
                               <?php endif; ?>
                               <?php if($hons): ?>
                               <tr>
                                    <th>HONS.</th>
                                    <td><?php echo e($hons->institution); ?></td>
                                    <td><?php echo e($hons->group); ?></td>
                                    <td><?php echo e($hons->gpa); ?></td>
                                    <td><?php echo e($hons->year); ?></td>
                                    

                               </tr>
                               <?php endif; ?>
                               <?php if($masters): ?>
                               <tr>
                                    <th>MASTERS</th>
                                    <td><?php echo e($masters->institution); ?></td>
                                    <td><?php echo e($masters->group); ?></td>
                                    <td><?php echo e($masters->gpa); ?></td>
                                    <td><?php echo e($masters->year); ?></td>
                                    

                               </tr>
                               <?php endif; ?>
                               <?php if($others): ?>
                               <tr>
                                    <th><?php echo e($others->title); ?></th>
                                    <td><?php echo e($others->institution); ?></td>
                                    <td><?php echo e($others->group); ?></td>
                                    <td><?php echo e($others->gpa); ?></td>
                                    <td><?php echo e($others->year); ?></td>
                                    

                               </tr>
                               <?php endif; ?>
                               <?php if($visitor->additional_skill): ?>
                               <tr>
                                    <th><?php echo e($visitor->additional_skill); ?></th>
                                    <td>-</td>
                                    <td>-</td>
                                    <td><?php echo e($visitor->additional_skill_score); ?></td>
                                    <td>-</td>
                                    

                               </tr>
                               <?php endif; ?>


                            </tbody>
                            
                        </table>
                        </div>
                            </fieldset>
                                                                  
                       

                        </div>
                        <div class="form-actions">
                            <div class="text-right">
                                <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Verify</button>
                            </div>
                        </div>
                    </form>




                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/student/visitor_details.blade.php ENDPATH**/ ?>
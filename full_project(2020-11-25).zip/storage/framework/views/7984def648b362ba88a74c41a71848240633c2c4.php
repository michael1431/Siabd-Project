
<?php $__env->startSection('title','Subject'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 
    <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Subject List</h4>
                </div>
                <div class="card-body">
                    
                    <form method="post" action="<?php echo e(route('setting.subject.store')); ?>" style="border:1px solid #ea1b23">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-body" style="margin:13px;">
                            <div class="form-group row">
                               
                                <label class="col-md-3 text-dark">Subject</label>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" id="">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Submit</button>
                                    </div>
                                </div>
                                
                            </div>
                            

                        </div>
                    </form>
                    <br>
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($subject->name); ?></td>
                                                <td><?php echo e($subject->created_at); ?></td>
                                                <td>
                                                    <button data-toggle="modal" data-target="#update" class="fa fa-edit btn btn-success" onclick="editForm(<?php echo e($subject); ?>)"></button>
                                                    
             
                                                 <form id="delete-form" action="<?php echo e(route('setting.subject.delete',$subject->id)); ?>" method="POST" style="display: none;">
                                                     <?php echo csrf_field(); ?>
                                                 </form>
                                                </td>
                                            </tr>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="5">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle-2" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle-2"> Update Subject</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <div class="card mb-5">
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data" id="subject_edit_form">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <label for="">Subject Name</label>
                                    <input type="text" class="form-control" name="name" id="name" value="">
                                </div>
                            </div>
                            
                            <button class="btn btn-primary ml-2" type="submit">Save changes</button>
                        </form>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    function editForm(data){
        var action="<?php echo e(url('')); ?>/Settings/subject_update/"+data.id;
        $('#subject_edit_form').attr('action',action);
        $('#name').attr('value',data.name);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/subject/create.blade.php ENDPATH**/ ?>
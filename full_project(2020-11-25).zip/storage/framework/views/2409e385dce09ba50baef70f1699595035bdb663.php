
<?php $__env->startSection('title','My Applications'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                  <h4 class="text-white">My Applications</h4>
                </div>
                <div class="card-body">
 
                    
                    <?php if(Auth::user()->role_id==2): ?>
                        <div class="table-responsive">
                            <table id="multi_col_order"
                                class="table table-striped table-bordered display no-wrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>University</th>
                                        <th>Subject</th>
                                        <th>Counselor</th>
                                        <th colspan="2"> Action </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $studentlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <?php if(Auth::user()->id==$student_list->user_id): ?>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($student_list->program->university->name); ?> - <?php echo e($student_list->program->country->name); ?></td>
                                        <td><?php echo e($student_list->program->subject->name); ?></td>
                                        <td><?php echo e($student_list->counselor ? $student_list->counselor->name : 'Yet Not Assign'); ?></td>
                                        <td><a class="btn btn-danger" target="_blank" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.edit',$student_list->id)); ?>">Details</a></td>
                                        <?php endif; ?>
                                    </tr> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><th colspan="9">There is no data for this query</th></tr>
                                    <?php endif; ?>
                                    
                                    
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

        


                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/student/update&remarks.blade.php ENDPATH**/ ?>
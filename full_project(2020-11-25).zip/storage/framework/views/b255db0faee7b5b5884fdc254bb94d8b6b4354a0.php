
<?php $__env->startSection('title','Accounts Head Edit'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    
    <!-- end row-->
    <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Accounts Head List</h4>
                </div>
                <div class="card-body">
                    
                    <form method="post" action="<?php echo e(route('account.head.update',$acc_type->id)); ?>" style="border:1px solid #ea1b23">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-body" style="margin:13px">
                            <div class="form-group row">
                               
                                <label class="col-md-2 text-dark">Accounts Head</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                    <input type="text" class="form-control" name="name" id="" value="<?php echo e($acc_type->name); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4 text-dark">
                                    <div class="form-group">
                                        <div class="form-check form-check-inline">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" class="custom-control-input" id="customControlValidation1" name="type" value="0" <?php echo e($acc_type->type ? '' : 'checked'); ?>>
                                                <label class="custom-control-label" for="customControlValidation1">Income</label>
                                            </div>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" class="custom-control-input" id="customControlValidation2" name="type" value="1" <?php echo e($acc_type->type ? 'checked' : ''); ?>>
                                                <label class="custom-control-label" for="customControlValidation2">Expense</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Submit</button>
                                    </div>
                                </div>
                                
                            </div>
                            

                        </div>
                    </form>
<br>
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Type</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($type->name); ?></td>
                                                <td><?php echo e($type->type?'Expense':'Income'); ?></td>
                                                <td><?php echo e($type->created_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('account.head.edit',$type->id)); ?>" class="fa fa-edit btn btn-success"></a>
                                                    <a class="fa fa-trash btn btn-danger" href="<?php echo e(route('account.head.delete',$type->id)); ?>"
                                                        onclick="event.preventDefault();
                                                                      document.getElementById('delete-form').submit();">
                                                     </a>
                 
                                                     <form id="delete-form" action="<?php echo e(route('account.head.delete',$type->id)); ?>" method="POST" style="display: none;">
                                                         <?php echo csrf_field(); ?>
                                                     </form>
                                                </td>
                                            </tr>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="5">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/cost-type/edit.blade.php ENDPATH**/ ?>
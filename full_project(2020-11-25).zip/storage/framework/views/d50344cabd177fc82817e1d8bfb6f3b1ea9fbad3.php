
<?php $__env->startSection('title','Student List'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Student List</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Counselor</th>
                                    <th>Status</th>
                                    <th colspan="2"> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $student_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($student_list->code); ?></td>
                                    <td><?php echo e($student_list->detail->name); ?></td>
                                    <td><?php echo e($student_list->detail->phone); ?></td>
                                    <td><?php echo e($student_list->program->university.'<br>'.$student_list->program->country); ?></td>
                                    <td><?php echo e($student_list->program->subject); ?></td>
                                    <td><?php echo e($student_list->counselor ? $student_list->counselor->name : 'Yet Not Assign'); ?></td>
                                    <td><?php echo e(strtoupper(str_replace('_',' ',$student_list->status))); ?></td>
                                    <td>
                                        <div class="form-group">
                                        <select name="status" class="custom-select mr-sm-2" id="change_status<?php echo e($student_list->id); ?>" onchange="changeStatus(<?php echo e($student_list->id); ?>)">
                                                <option value="0">Change Status</option>
                                                <option value="new_leads" class="text-warning">New Applied</option>
                                                <option value="scheduled" class="text-info">Scheduled</option>
                                                <option value="not_interested" class="text-danger">Not Interested</option>
                                                <option value="interested" class="text-success">Interested</option>
                                                <option value="not_answered" class="text-dark">Not Answered</option>
                                            </select>
                                        </div>
                                    </td>
                            
                                    <td><a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.show',$student_list->id)); ?>">Details</a></td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="9">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
function changeStatus(student_id){
    var status=$('#change_status'+student_id).val();
    if(status==0){
        alert('Select One of Options');
    }else{
        $.ajax({
            type: "GET",
            url: "<?php echo e(route('default.change_status')); ?>",
            data: { status:status, student_id:student_id }, 
            success: function( msg ) {
                console.log( msg );
                if(msg){
                    location.reload();
                }
            }
        });
    }
}
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/student/status_list.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Program Create Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Add Programe</h4>
                </div>
                <div class="card-body">


                    <form method="post" action="<?php echo e(route('setting.program.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                       
                            <fieldset style="border: 1px groove #ea1b23 !important;padding: 0 1.4em 1.4em 1.4em !important; margin: 0 0 2em 0 !important;-webkit-box-shadow:  0px 0px 0px 0px #000;box-shadow:  0px 0px 0px 0px #000;">
                                <legend style="width:inherit;padding:0 10px;border-bottom:none;">Program Details</legend>
                                <div class="form-body">
                                    <div class="form-group row">
                                        <label class="col-md-2">Select Country </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="country_id" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($country->id); ?>"><?php echo e(strtoupper($country->name)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                    
                                                </select>
                                            </div>
                                        </div>
                                        <label class="col-md-2">Select Subject </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="subject_id" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                           
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">Select University </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="university_id" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u=>$university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($university->id); ?>"><?php echo e($university->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <label class="col-md-2">Select Degree Type</label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select name="degree_type_id" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                    <option selected="">Choose...</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                           
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">Programe Name </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" name="degree" class="form-control">
                                            </div>
                                        </div>
                                        <label class="col-md-2">Programe Code </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" name="code" class="form-control">
                                            </div>
                                        </div>
                                           
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2">Base </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" name="base" class="form-control">
                                            </div>
                                        </div>
                                        <label class="col-md-2">Tuition Fee </label>
                                        
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <input type="text" name="tuition_fee" class="form-control">
                                            </div>
                                        </div>
                                           
                                    </div>
                            </fieldset>
                        </div>
                        <div class="form-actions">
                            <div class="text-right">
                                <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Submit</button>
                            </div>
                        </div>
                    </form>




                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
        <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Programe List</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Code</th>
                                    <th>Degree</th>
                                    <th>University</th>
                                    <th>Subject</th>
                                    <th>Country</th>
                                    <th>Tuition Fee</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($programme->code); ?></td>
                                    <td><?php echo e($programme->degree?$programme->degree:''); ?></td>
                                    <td><?php echo e($programme->university?$programme->university->name:''); ?></td>
                                    <td><?php echo e($programme->subject?$programme->subject->name:''); ?></td>
                                    <td><?php echo e($programme->country?$programme->country->name:''); ?></td>
                                    <td><?php echo e($programme->tuition_fee); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('setting.program.edit',$programme->id)); ?>" class="fa fa-edit btn btn-success" ></a>
                                    </td>
                                    
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                        <?php echo e($programmes->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/siabd.ringersoft.com/resources/views/program/create.blade.php ENDPATH**/ ?>
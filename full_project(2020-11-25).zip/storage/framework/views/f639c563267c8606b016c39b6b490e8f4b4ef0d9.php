
<?php $__env->startSection('title','Eligibility Result'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Multi-column ordering</h4>
                    <h6 class="card-subtitle">On a per-column basis (i.e. order by a specific column and
                        then a secondary column if the data in the first column is identical), through the
                        <code> columns.orderData</code> option.</h6>
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Code</th>
                                    <th>Degree</th>
                                    <th>University</th>
                                    <th>Country</th>
                                    <th>Tuition Fee</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($programme->code); ?></td>
                                    <td><?php echo e($programme->degree); ?></td>
                                    <td><?php echo e($programme->university); ?></td>
                                    <td><?php echo e($programme->country); ?></td>
                                    <td><?php echo e($programme->tuition_fee); ?></td>
                                    <td><a class="btn btn-danger" style="background-color: #ea1b23" href="<?php echo e(route('studentlist.create',['program_id'=>$programme->id])); ?>">Apply</a></td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/eligibility_test_result.blade.php ENDPATH**/ ?>
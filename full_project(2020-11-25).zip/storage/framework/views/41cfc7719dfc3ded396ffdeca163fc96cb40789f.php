
<?php $__env->startSection('title','Country'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    
    <!-- end row-->
    <div class="row">
        <div class="col-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">Country List</h4>
                </div>
                <div class="card-body">
                    
                    <form method="post" action="<?php echo e(route('setting.country.store')); ?>" style="border:1px solid #ea1b23" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-body" style="margin:13px;">
                            <div class="form-group row">
                               
                                <label class="col-md-2 text-dark">Country Name</label>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" id="">
                                    </div>
                                </div>
                                <div class="col-md-4 text-dark">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Image</span>
                                            </div>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="inputGroupFile01" name="image">
                                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Submit</button>
                                    </div>
                                </div>
                                
                            </div>
                            

                        </div>
                    </form>
                    <br>
                    <div class="table-responsive">
                        <table id="multi_col_order"
                            class="table table-striped table-bordered display no-wrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($country->name); ?></td>
                                                <td><img class="img-circle" width="100px" src="<?php echo e($country->flag_image); ?>"/></td>
                                                <td><?php echo e($country->created_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('setting.country.edit',$country->id)); ?>" class="fa fa-edit btn btn-success"></a>
                                                    
                                                    <a class="fa fa-trash btn btn-danger" href="<?php echo e(route('setting.country.delete',$country->id)); ?>"
                                                    onclick="event.preventDefault();
                                                                  document.getElementById('delete-form').submit();">
                                                 </a>
             
                                                 <form id="delete-form" action="<?php echo e(route('setting.country.delete',$country->id)); ?>" method="POST" style="display: none;">
                                                     <?php echo csrf_field(); ?>
                                                 </form>
                                                </td>
                                            </tr>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><th colspan="5">There is no data for this query</th></tr>
                                <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/country/create.blade.php ENDPATH**/ ?>
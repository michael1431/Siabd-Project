<?php $__env->startSection('title','Eligibility Check'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title mb-3">Eligibility Check</h4>

                    <ul class="nav nav-tabs mb-3">
                        <li class="nav-item">
                            <a href="#home" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                <i class="mdi mdi-home-variant d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 1</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#profile" data-toggle="tab" aria-expanded="false"
                                class="nav-link">
                                <i class="mdi mdi-account-circle d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 2</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link">
                                <i class="mdi mdi-settings-outline d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 3</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#settings2" data-toggle="tab" aria-expanded="false" class="nav-link">
                                <i class="mdi mdi-settings-outline d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Step 4</span>
                            </a>
                        </li>
                    </ul>
                <form method="post" action="<?php echo e(route('eligibility_check')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="tab-content">
                        <div class="tab-pane show active" id="home">
                            <h4 class="card-title">Select All Option To Query Your Desired Degree</h4>
                               
                                    <div class="form-body">
                                        <div class="form-group row">
                                            <label class="col-md-2">Select Country </label>
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select name="country" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <option value="<?php echo e($country); ?>"><?php echo e(strtoupper($country)); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            
                                                        <?php endif; ?>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                            <label class="col-md-2">Select Subject </label>
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select name="subject" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <option value="<?php echo e($subject); ?>"><?php echo e($subject); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                               
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-2">Select University </label>
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select name="university" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university=>$u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <option value="<?php echo e($university); ?>"><?php echo e($university); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <label class="col-md-2">Select Degree </label>
                                            
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <select name="degree" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <option value="<?php echo e($degree->id); ?>"><?php echo e($degree->degree); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                               
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <div class="text-right">
                                            
                                            <a href="#profile" data-toggle="tab" aria-expanded="false" class="nav-link">
                                                <i class="mdi mdi-account-circle d-lg-none d-block mr-1"></i>
                                                <span class="d-none d-lg-block">Next</span>
                                            </a>
                                        </div>
                                    </div>
                                
                        </div>
                        <div class="tab-pane" id="profile">
                            
                               
                                    <div class="form-body">
                                        <div class="form-group row">
                                            <label class="text-dark col-md-3">Examination</label>
                                            <label class="text-dark col-md-3">Group/Major</label>
                                            <label class="text-dark col-md-3">GPA</label> 
                                        </div>
                                        <div class="form-group row">
                                            <label class="text-dark col-md-3">SSC</label>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select name="ssc_group" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <option value="1">Science</option>
                                                        <option value="2">Business Studies</option>
                                                        <option value="3">Humanities</option>
                                                        <option value="4">General</option>
                                                        <option value="5">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="number" class="form-control" max="5" step=".01">
                                            </div>  
                                        </div>
                                        <div class="form-group row">
                                            <label class="text-dark col-md-3">HSC</label>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select name="hsc_group" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <option value="1">Science</option>
                                                        <option value="2">Business Studies</option>
                                                        <option value="3">Humanities</option>
                                                        <option value="4">General</option>
                                                        <option value="5">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="number" class="form-control" max="5" step=".01">
                                            </div>
                                            
                                            
                                               
                                        </div>
                                        <div class="form-group row">
                                            <label class="text-dark col-md-3">Hon's</label>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select name="hsc_group" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <option value="1">Science</option>
                                                        <option value="2">Business Studies</option>
                                                        <option value="3">Humanities</option>
                                                        <option value="4">General</option>
                                                        <option value="5">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="number" class="form-control" max="5" step=".01">
                                            </div>
                                            
                                            
                                               
                                        </div>
                                        <div class="form-group row">
                                            <label class="text-dark col-md-3">Masters</label>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select name="hsc_group" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                        <option selected="">Choose...</option>
                                                        <option value="1">Science</option>
                                                        <option value="2">Business Studies</option>
                                                        <option value="3">Humanities</option>
                                                        <option value="4">General</option>
                                                        <option value="5">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="number" class="form-control" max="5" step=".01">
                                            </div>
                                            
                                            
                                               
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <div class="text-right">
                                            
                                           
                                                <a href="#settings" data-toggle="tab" aria-expanded="false" class="nav-link">
                                                    <i class="mdi mdi-settings-outline d-lg-none d-block mr-1"></i>
                                                    <span class="d-none d-lg-block">Next</span>
                                                </a>
                                        </div>
                                    </div>
                                
                        </div>
                        <div class="tab-pane" id="settings2">
                            <section class="elementor-element elementor-element-2bc358d elementor-section-full_width aux-appear-watch-animation aux-mask-from-left elementor-section-height-min-height elementor-hidden-phone elementor-section-height-default elementor-section-items-middle elementor-section elementor-top-section aux-animated aux-animated-once" data-id="2bc358d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                <div class="elementor-background-overlay"></div>
                                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
                    <div class="aux-parallax-section elementor-element elementor-element-b18c654 elementor-column elementor-col-100 elementor-top-column" data-id="b18c654" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                        <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-49dabb1 aux-appear-watch-animation aux-fade-in-up-1 elementor-widget elementor-widget-aux_modern_heading aux-animated aux-animated-once" data-id="49dabb1" data-element_type="widget" data-widget_type="aux_modern_heading.default">
                    <div class="elementor-widget-container">
                <section class="aux-widget-modern-heading">
                <div class="aux-widget-inner"><h5 class="aux-modern-heading-primary">COUNTRIES</h5><h3 class="aux-modern-heading-secondary"><span class="aux-head-before">WE OFFER</span></h3></div>
            </section>		</div>
                    </div>
                    <section class="elementor-element elementor-element-37e566c elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="37e566c" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
                    <div class="aux-parallax-section elementor-element elementor-element-4c08fb9 aux-appear-watch-animation aux-fade-in-right-1 elementor-column elementor-col-25 elementor-inner-column aux-animated aux-animated-once" data-id="4c08fb9" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                        <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-272655a elementor-widget elementor-widget-image" data-id="272655a" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/USA/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/US.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/US.png 500w, https://siabd.com/wp-content/uploads/2020/06/US-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/US-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                    <div class="elementor-element elementor-element-f53e4a9 elementor-widget elementor-widget-image" data-id="f53e4a9" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/europe/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/EUROPE.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/EUROPE.png 500w, https://siabd.com/wp-content/uploads/2020/06/EUROPE-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/EUROPE-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                            </div>
                </div>
            </div>
                    <div class="aux-parallax-section elementor-element elementor-element-baada9e aux-appear-watch-animation aux-fade-in-right-1 elementor-column elementor-col-25 elementor-inner-column aux-animated aux-animated-once" data-id="baada9e" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                        <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-095057a elementor-widget elementor-widget-image" data-id="095057a" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/UK/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/UK.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/UK.png 500w, https://siabd.com/wp-content/uploads/2020/06/UK-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/UK-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                    <div class="elementor-element elementor-element-f95ba36 elementor-widget elementor-widget-image" data-id="f95ba36" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/india/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/IND.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/IND.png 500w, https://siabd.com/wp-content/uploads/2020/06/IND-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/IND-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                            </div>
                </div>
            </div>
                    <div class="aux-parallax-section elementor-element elementor-element-50842d9 aux-appear-watch-animation aux-fade-in-right-1 elementor-column elementor-col-25 elementor-inner-column aux-animated aux-animated-once" data-id="50842d9" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                        <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-ef18287 elementor-widget elementor-widget-image" data-id="ef18287" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/canada/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/CANADA.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/CANADA.png 500w, https://siabd.com/wp-content/uploads/2020/06/CANADA-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/CANADA-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                    <div class="elementor-element elementor-element-a2a891b elementor-widget elementor-widget-image" data-id="a2a891b" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/china/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/CHINA.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/CHINA.png 500w, https://siabd.com/wp-content/uploads/2020/06/CHINA-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/CHINA-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                            </div>
                </div>
            </div>
                    <div class="aux-parallax-section elementor-element elementor-element-7c5072c aux-appear-watch-animation aux-fade-in-right-1 elementor-column elementor-col-25 elementor-inner-column aux-animated aux-animated-once" data-id="7c5072c" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                        <div class="elementor-widget-wrap">
                    <div class="elementor-element elementor-element-a57fca1 elementor-widget elementor-widget-image" data-id="a57fca1" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/australia/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/AUSTRALIA.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/AUSTRALIA.png 500w, https://siabd.com/wp-content/uploads/2020/06/AUSTRALIA-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/AUSTRALIA-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                    <div class="elementor-element elementor-element-fe5833c elementor-widget elementor-widget-image" data-id="fe5833c" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-image">
                                                <a href="https://siabd.com/malaysia/">
                                <img src="https://siabd.com/wp-content/uploads/2020/06/MALAY.png" class="attachment-large size-large" alt="" srcset="https://siabd.com/wp-content/uploads/2020/06/MALAY.png 500w, https://siabd.com/wp-content/uploads/2020/06/MALAY-300x300.png 300w, https://siabd.com/wp-content/uploads/2020/06/MALAY-150x150.png 150w" sizes="(max-width: 500px) 100vw, 500px" width="500" height="500">								</a>
                                                </div>
                    </div>
                    </div>
                            </div>
                </div>
            </div>
                            </div>
                </div>
            </section>
                    <div class="elementor-element elementor-element-0768eb9 elementor-widget elementor-widget-spacer" data-id="0768eb9" data-element_type="widget" data-widget_type="spacer.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-spacer">
                <div class="elementor-spacer-inner"></div>
            </div>
                    </div>
                    </div>
                    <div class="elementor-element elementor-element-5fd6f9b elementor-widget elementor-widget-text-editor" data-id="5fd6f9b" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-text-editor elementor-clearfix"><p>The core team of SIA Consultancy is spearheaded by people with more than seven years of domain expertise. They have precision knowledge in the fields of Immigration, Visa processing and other related services. To ensure prompt and hassle-free services we have a team of handpicked executives who go through rigorous &amp; in-depth training on country-specific immigration and visa processing norms &amp; rules to arm them with the requisite knowledge. Our executives have thorough knowledge &amp; hands-on experience in dealing with immigration procedures followed by Embassies &amp; High Commissions.</p><p>We assign a case officer who will guide every registered applicant through the entire application process and assist them at every stage. They work in tandem with you to complete the process on time ensuring successful results.</p><p>Just walk into our office and you can talk to our counselor to learn more about the country of your interest. With our tailor-made solutions, you will have the flexibility to choose the right package that is both appropriate and affordable.</p></div>
                    </div>
                    </div>
                            </div>
                </div>
            </div>
                            </div>
                </div>
            </section>
                        </div>
                        <div class="tab-pane" id="settings">
                            <div class="form-body">
                                <div class="form-group row">
                                    <label class="col-md-2">IELTS </label>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation2">yes </label>
                                                </div>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation3">no </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control" max="9" step=".01">
                                    </div>
                                    
                                       
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2">TOFEL </label>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation2">yes </label>
                                                </div>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation3">no </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control" max="9" step=".01">
                                    </div>
                                    
                                       
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2">GRE </label>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation2">yes </label>
                                                </div>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation3">no </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control" max="9" step=".01">
                                    </div>
                                    
                                       
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2">GMAT </label>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation2">yes </label>
                                                </div>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked">
                                                    <label class="custom-control-label" for="customControlValidation3">no </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control" max="9" step=".01">
                                    </div>
                                    
                                       
                                </div>
                                
                            <div class="form-actions">
                                <div class="text-right">
                                    <button type="submit" class="btn btn-info">Submit</button>
                                   
                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/home.blade.php ENDPATH**/ ?>
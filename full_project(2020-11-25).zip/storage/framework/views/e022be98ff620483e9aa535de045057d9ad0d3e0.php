
<?php $__env->startSection('title','Edit User Role'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card" style="border:1px solid #ea1b23">
                <div class="card-header" style="background-color: #ea1b23">
                    <h4 class="text-white">User Role List</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('user.role.update',$role->id)); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-body">
                            <div class="form-group row">
                                <div class="col-md-1"></div>
                                <label class="col-md-2 text-dark">Role Name:* </label>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" id="" value="<?php echo e($role->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" id="checked_entirely" onclick="checkEntire()" value="1">
                                    </div>

                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <table id="multi_col_order" class="table table-striped table-bordered display"
                            style="width:100%">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Permissions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                
                                    <tr>
                                        <th><h5><?php echo e($key); ?></h5></th>
                                        <th>
                                                <input id="<?php echo e(strtolower($key)); ?>-select-all" onclick="checkAll('<?php echo e(strtolower($key)); ?>')" type="checkbox" class="allCheck">
                                                <label for="<?php echo e(strtolower($key)); ?>-select-all"> Select all <?php echo e($key); ?></label>
                                        </th>
                                        <th>
                                            <?php $__empty_2 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            
                                                <div class="checkbox">
                                                    <input  type="checkbox" class="<?php echo e(strtolower($key)); ?>-select allCheck" name="asignpermission[]" value="<?php echo e($permission->id); ?>" <?php echo e(checkPermission($role->id,$permission->id)?'checked':''); ?>>
                                                    <label for="demo-form-checkbox"><?php echo e($permission->lebel); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <?php endif; ?>
                                        </th>
                                    </tr>                                           
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>

                        </table>
                        </div>
                            
                        <div class="form-actions">
                            <div class="text-right">
                                <button type="submit" class="btn btn-danger" style="background-color: #ea1b23">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">
    function checkAll(lebel_group){
        var consd=$("."+lebel_group+"-select").attr('checked');
        if(consd){
             $("."+lebel_group+"-select").attr('checked', false);
             }else{
                $("."+lebel_group+"-select").attr('checked', true);
             }
               
        }
    function checkEntire(){
        var checkedEntirely=$("#checked_entirely").val();
            if(checkedEntirely){
                $(".allCheck").prop("checked",true);
                $("#checked_entirely").val(0);   
            }else{
                $(".allCheck").prop("checked",false);
                $("#checked_entirely").val(1);    
            }
         
        }
        

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siabd\resources\views/users/edit-role.blade.php ENDPATH**/ ?>
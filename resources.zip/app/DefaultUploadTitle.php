<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DefaultUploadTitle extends Model
{
    protected $fillable = ['title'];
}
